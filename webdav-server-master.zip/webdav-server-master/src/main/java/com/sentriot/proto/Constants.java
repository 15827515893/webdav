package com.sentriot.proto;

import java.util.Arrays;
import java.util.List;

public class Constants {

    public static final List<String> METHOD_HEAD = Arrays.asList("PROPFIND","PROPPATCH","MKCOL","COPY","MOVE","LOCK","UNLOCK");

}
