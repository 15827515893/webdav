package com.sentriot.proto;



import java.io.*;
import java.net.*;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;


/**
 * @author hj
 */
@Slf4j
@Component
@WebFilter(filterName = "MyFilter", urlPatterns = "/*")
public class DemoFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("初始化过滤器!");
    }

    @Override
    public void destroy() {
        System.out.println("销毁过滤器!");
    }

    private String logRequestBody(MultiReadHttpServletRequest request) {
        MultiReadHttpServletRequest wrapper = request;
        if (wrapper != null) {
            try {
                String bodyJson = wrapper.getBodyJsonStrByJson(request);
                String url = wrapper.getRequestURI().replace("//", "/");
                System.out.println("-------------------------------- 请求url: " + url + " --------------------------------");
                log.info("`{}` 接收到的参数: {}",url , bodyJson);
                return bodyJson;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void logResponseBody(MultiReadHttpServletRequest request, MultiReadHttpServletResponse response, long useTime) {
        MultiReadHttpServletResponse wrapper = response;
        if (wrapper != null) {
            byte[] buf = wrapper.getBody();
            if (buf.length > 0) {
                String payload;
                try {
                    payload = new String(buf, 0, buf.length, wrapper.getCharacterEncoding());
                } catch (UnsupportedEncodingException ex) {
                    payload = "[unknown]";
                }
                log.info("`{}`  耗时:{}ms  返回的参数: {}", request.getRequestURI(), useTime, payload);
            }
        }
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
                         FilterChain filterChain) throws IOException, ServletException {
        redirect(servletRequest,  servletResponse, filterChain);
    }

    private void redirect(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("================进入过滤器=================");
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String requestURI = req.getRequestURI();
         // 转发请求，如果是同一个服务器可以直接调用转发请求的方法，这里要做的是转发请求另一个服务的接口，然后返回请求结果
         // 1、地址栏有传参数需要进行拼接参数
         String queryString = req.getQueryString();//地址栏参数
         if (queryString != null) {
             // 地址有参数，拼接
             requestURI = requestURI + "?" + queryString;
         }
         // 2、拼接转发的IP和端口

         String url = "http://192.168.126.110:8888" + requestURI;
         log.info("转发路径{}",url);

        HttpURLConnection connection = null;
        InputStream is = null;
        BufferedReader br = null;
        StringBuffer result = new StringBuffer();
        OutputStream  out = response.getOutputStream();
        try {
            //创建连接
            URL url1 = new URL(url);
            connection = (HttpURLConnection) url1.openConnection();
            //设置请求方式
            connection.setRequestMethod("POST");
            connection.setRequestProperty("X-HTTP-Method-Override", "LOCK");
            // connection.setDoOutput(true);
            List<String> headerNames = Collections.list(req.getHeaderNames());
            for(String headerName : headerNames) {
                List<String> headerValues = Collections.list(req.getHeaders(headerName));
                for (String headerValue : headerValues) {
                    connection.setRequestProperty(headerName, headerValue);
                }
            }

            //设置连接超时时间
            connection.setReadTimeout(15000);
            //开始连接
            connection.connect();
//            OutputStream os  = connection.getOutputStream();
//            if (null!=os){
//                byte[] body = parseRequestBody(req);//body
//                os.write(body);
//                os.flush();
//            }
            Map<String,List<String>> resultHeaders  = connection.getHeaderFields();
            Iterator<String> iteratorKey = connection.getHeaderFields().keySet().iterator();

            while (iteratorKey.hasNext()){
                String key = iteratorKey.next();
                List<String> list = resultHeaders.get(key);
                resp.addHeader(key,list.get(0));
            }
            //获取响应数据
            if (connection.getResponseCode() == 200) {
                //获取返回的数据
                is = connection.getInputStream();
                if (null != is) {
                    byte[] b = new byte[2048];
                    int len;
                    while ((len = is.read(b)) != -1) {
                        out.write(b, 0, len);
                    }
                }
            }
        }catch (Exception e){
            throw new RuntimeException("",e);
        }


//         // 3、请求类型
//         String method = req.getMethod();
//         HttpMethod httpMethod = HttpMethod.resolve(method);//method
//         // 4、请求头
//         MultiValueMap<String, String> headers = parseRequestHeader(req);//header
//         // 5、请求体
//         byte[] body = parseRequestBody(req);//body
//
//         //  6、封装发singhttp请求
//         RequestEntity requestEntity = new RequestEntity(body, headers, httpMethod, URI.create(url));
//         RestTemplate restTemplate = new RestTemplate();
//         //编码格式转换
//         restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
//         ResponseEntity<String> result = restTemplate.exchange(requestEntity, String.class);
//
//         // 将转发请求得到的结果和响应头返回客户端
//         String resultBody = result.getBody();
//         HttpHeaders resultHeaders = result.getHeaders();
         String contentType = connection.getContentType();
         if (contentType != null) {
             resp.setContentType(contentType);
         }
         resp.setStatus(connection.getResponseCode());
         // resp.setCharacterEncoding("UTF-8");// 在getWriterz之前执行，否则不生效
        out.flush();
    }

    private byte[] parseRequestBody(HttpServletRequest request) throws IOException {
        InputStream inputStream = request.getInputStream();
        return StreamUtils.copyToByteArray(inputStream);
    }

    /**
     * request header
     * @param request
     * @return
     */
    private MultiValueMap<String, String> parseRequestHeader(HttpServletRequest request) {
        HttpHeaders httpHeaders = new HttpHeaders();
        List<String> headerNames = Collections.list(request.getHeaderNames());
        for(String headerName : headerNames) {
            List<String> headerValues = Collections.list(request.getHeaders(headerName));
            for (String headerValue : headerValues) {
                httpHeaders.add(headerName, headerValue);
            }
        }
        return httpHeaders;
    }

}

